<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProjectValue extends Model
{
    //
}
